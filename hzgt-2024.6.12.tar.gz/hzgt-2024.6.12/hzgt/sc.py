class SCError(Exception):
    pass

